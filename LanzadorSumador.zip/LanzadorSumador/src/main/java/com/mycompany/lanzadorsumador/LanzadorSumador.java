package com.mycompany.lanzadorsumador;

import com.mycompany.lanzadorsumador.Sumador;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Random;

public class LanzadorSumador {
    public static void main(String[] args) {

        Random random = new Random();

        try {

            String linea;

            String[] numeros = new String[2];

            numeros[0] = String.valueOf(random.nextInt(1000) + 1);
            numeros[1] = String.valueOf(random.nextInt(1000) + 1);

            Process p1 = ProcesoJava.exec(Sumador.class, numeros);

            p1.waitFor();

            BufferedReader bufferedReader = p1.inputReader();

            linea = bufferedReader.readLine();

            System.out.println(linea);

            // proceso hijo2
            Process p2 = ProcesoJava.exec(Sumador.class, numeros);

            p2.waitFor();

            bufferedReader = p2.inputReader();

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File("res/salidaHijo2.txt")));

            linea = bufferedReader.readLine();

            bufferedWriter.write(linea);

            bufferedWriter.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

}