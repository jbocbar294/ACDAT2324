package com.mycompany.lanzadorsumador;

public class Sumador {

    public static void main(String[] args) {

        if (args.length == 2) {
            
            int numero = Integer.parseInt(args[0]) + Integer.parseInt(args[1]);

            System.out.println(numero);
            
        } else {
            System.out.println("Deben pasarse al menos dos argumentos.");    
        }
        
        

    }

}