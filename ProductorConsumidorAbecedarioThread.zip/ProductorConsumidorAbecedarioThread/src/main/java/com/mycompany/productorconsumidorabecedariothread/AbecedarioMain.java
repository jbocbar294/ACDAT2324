/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productorconsumidorabecedariothread;

/**
 *
 * @author juanm
 */
public class AbecedarioMain {

    public static void main(String[] args) {
        Metodos metodos = new Metodos();
        
        Hilo1 h1 = new Hilo1(metodos);
	Hilo2 h2 = new Hilo2(metodos);
	
        h1.start();
        h2.start();
        
	// Espera de finalización de todo lo consumido
	try {
		h2.join();
	} catch (InterruptedException e) {
	}
		
	System.out.println("FIN");
    }
}
