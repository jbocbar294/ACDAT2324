package com.mycompany.productorconsumidorabecedariothread;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Metodos {
    
    private int numero;
    private boolean ocupado = false;
    
    public int cogerNumero() {
        
        while (!ocupado) {
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Metodos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        ocupado = true;
        
        int numGenerado = numero;
        
        notifyAll();
        
        return numGenerado;
    }
    
    public void dejarNumero(int n) {
        while (ocupado) {
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Metodos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        ocupado = false;
        
        numero = n;
        
        notifyAll();
    }
    
}
