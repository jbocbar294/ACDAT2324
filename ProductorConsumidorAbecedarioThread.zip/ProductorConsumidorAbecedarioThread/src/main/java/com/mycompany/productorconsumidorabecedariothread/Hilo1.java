package com.mycompany.productorconsumidorabecedariothread;

public class Hilo1 extends Thread {
    private Metodos metodos;
    
    public Hilo1(Metodos metodos) {
        this.metodos = metodos;
    }
    
    public void run() {
        for (int i = 0; i < 10; i++) {
            int numeroAleatorio = (int) (Math.random() * 100) + 1;
            
            metodos.dejarNumero(numeroAleatorio);
            System.out.println("H1: " + numeroAleatorio);
        }
    }
    
    
    
}
