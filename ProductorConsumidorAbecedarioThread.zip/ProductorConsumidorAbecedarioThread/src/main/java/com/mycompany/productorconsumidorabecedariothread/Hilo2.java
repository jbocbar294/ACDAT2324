package com.mycompany.productorconsumidorabecedariothread;

public class Hilo2 extends Thread {
    private Metodos metodos;
    
    public Hilo2(Metodos metodos) {
        this.metodos = metodos;
    }
    
    public void run() {
		for (int i = 0; i < 10; i++) {
			// Se recoge la letra
			int num = metodos.cogerNumero();
			
			System.out.println("H2: " + num);
		}
	}
}
