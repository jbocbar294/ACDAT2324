package com.mycompany.relevos;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Relevos implements Runnable {

    @Override
    public void run() {
        correr();
    }
    
    private synchronized void correr() {
        try {
            System.out.println(Thread.currentThread().getName() + " corriendo...");
            Thread.sleep(1000);
            System.out.println("Termino de correr.");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Relevos.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
