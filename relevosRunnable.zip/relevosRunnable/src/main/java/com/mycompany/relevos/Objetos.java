package com.mycompany.relevos;

public class Objetos {
    
    private String nombre;
    
    public String getNombre(){
        return this.nombre;
    }
    
}
