package com.mycompany.relevos;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        Relevos relevo = new Relevos();
        
        Thread thread1 = new Thread(relevo, "thread1");
        Thread thread2 = new Thread(relevo, "thread2");
        Thread thread3 = new Thread(relevo, "thread3");
        Thread thread4 = new Thread(relevo, "thread4");
        
        thread1.start();
        try {
            thread1.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        thread2.start();
        try {
            thread2.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        thread3.start();
        try {
            thread3.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        thread4.start();
        try {
            thread4.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
