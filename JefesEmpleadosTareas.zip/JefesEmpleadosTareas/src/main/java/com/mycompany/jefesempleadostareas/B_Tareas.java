package com.mycompany.jefesempleadostareas;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class B_Tareas {

    int contador = 0000;
    ArrayList<String> listaTareas = new ArrayList<>();

    public synchronized void crearTarea() {

        contador++;
        listaTareas.add(String.valueOf("Tarea_" + contador));
        System.out.print(" Crear Tarea::::::  ");

        for (int i = 0; i < listaTareas.size(); i++) {
            System.out.print(listaTareas.get(i) + " | ");
        }
        System.out.println("\n");

        try {
            Thread.sleep(200);
        } catch (InterruptedException ex) {
            Logger.getLogger(B_Tareas.class.getName()).log(Level.SEVERE, null, ex);
        }

        notifyAll();
    }

    public synchronized void hacerTarea() {

        while (listaTareas.size() == 0) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }

        listaTareas.remove(listaTareas.size() - 1);
        System.out.print("Quitar Tarea::::::  ");

        for (int i = 0; i < listaTareas.size(); i++) {
            System.out.print(listaTareas.get(i) + " | ");
        }
        System.out.println("\n");

        try {
            Thread.sleep(200);
        } catch (InterruptedException ex) {
            Logger.getLogger(B_Tareas.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
