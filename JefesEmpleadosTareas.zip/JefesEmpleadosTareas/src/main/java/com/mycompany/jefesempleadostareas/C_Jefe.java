package com.mycompany.jefesempleadostareas;

public class C_Jefe extends Thread {

    private B_Tareas tareas;

    public C_Jefe(B_Tareas tareas) {
        this.tareas = tareas;
    }

    public void run() {
        for (int i = 0; i < 40; i++) {
            tareas.crearTarea();
        }
    }
}
