package com.mycompany.jefesempleadostareas;

public class A_GestorTrabajo {

    public static void main(String args[]) {
        B_Tareas tareas = new B_Tareas();
        
        C_Jefe jefe1 = new C_Jefe(tareas);
        C_Jefe jefe2 = new C_Jefe(tareas);
        D_Empleado empleado1 = new D_Empleado(tareas);
        D_Empleado empleado2 = new D_Empleado(tareas);

        jefe1.start();
        // jefe2.start();
        empleado1.start();
        empleado2.start();

    }
}
