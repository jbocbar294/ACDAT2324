package com.mycompany.jefesempleadostareas;

public class D_Empleado extends Thread {

    private B_Tareas tareas;

    public D_Empleado(B_Tareas tareas) {
        this.tareas = tareas;
    }

    public void run() {
        for (int i = 0; i < 20; i++) {
            tareas.hacerTarea();
        }
    }
}
