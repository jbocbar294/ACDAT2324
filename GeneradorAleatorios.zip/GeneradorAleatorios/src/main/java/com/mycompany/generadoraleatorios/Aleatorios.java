package com.mycompany.generadoraleatorios;

import java.io.BufferedReader;
import java.util.Scanner;

public class Aleatorios {
    public static void main(String[] args) {
        
        String n;
        
        Scanner sc = new Scanner(System.in);
        
        char sn = 's';
        
        try {
            
            do {
                
                Process p1 = ProcesoJava.exec(GeneradorAleatorios.class);

                p1.waitFor();

                BufferedReader bufferedReader = p1.inputReader();

                n = bufferedReader.readLine();
            
                System.out.println(n);
                
                System.out.print("\n\nQuieres generar otro número?");
                
                sn = sc.next().charAt(0);
            
            } while (sn == 's');

            

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
    }
    
    
    
}
