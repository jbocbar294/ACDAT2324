package com.mycompany.generadoraleatorios;

import java.util.Random;

public class GeneradorAleatorios {

    public static void main(String[] args) {
        
        Random random = new Random();
        
        int n = random.nextInt(10);
        
        System.out.println(n);
        
        System.exit(n);
        
    }
}
